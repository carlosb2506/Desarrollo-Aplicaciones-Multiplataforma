/**
 * 
 */
/**
 * 
 */
module DesahogApp {
	requires java.desktop;
}