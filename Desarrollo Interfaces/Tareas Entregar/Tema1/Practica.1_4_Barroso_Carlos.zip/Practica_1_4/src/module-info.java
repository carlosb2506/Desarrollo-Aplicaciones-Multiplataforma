/**
 * 
 */
/**
 * 
 */
module Practica_1_4 {
	requires java.desktop;
}